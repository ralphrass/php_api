<?php
/*
Constantes de configuração de ambiente de produção.
*/

// Banco de dados
const DB_HOST = 'localhost';
const DB_PORT = 5432;
const DB_USER = 'postgres';
const DB_PASSWORD = '';
const DB_DATABASE = 'teufuturo';

// Envio de email
const MAIL_HOST = 'smtp.ralph.com.br';
const MAIL_USERNAME = 'no-reply@ralph.com.br';
const MAIL_PASSWORD = 'outraSenhaDoRalph';
const MAIL_PORT = 587;
const MAIL_FROM = 'API do Ralph';